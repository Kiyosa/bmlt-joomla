DROP TABLE IF EXISTS `#__bmlt_settings`;
